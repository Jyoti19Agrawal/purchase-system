package com.mobile.service;

import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;

public interface MobileService {
	
	public int addPurchaseDetails(PurchaseDetail pbean) throws MobileException;

}
