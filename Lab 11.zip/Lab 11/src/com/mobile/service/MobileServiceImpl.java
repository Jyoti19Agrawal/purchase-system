package com.mobile.service;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.dao.MobileDao;
import com.mobile.dao.MobileDaoImpl;
import com.mobile.exception.MobileException;

public class MobileServiceImpl implements MobileService{
	private MobileDao mobileDao=new MobileDaoImpl();
	@Override
	public int addPurchaseDetails(PurchaseDetail bean) throws MobileException {
		int id = mobileDao.addPurchaseDetails(bean);
		return id;
	}

}
