package com.mobile.pl;

import java.util.Scanner;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;
import com.mobile.service.MobileService;
import com.mobile.service.MobileServiceImpl;

public class MPSApp {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int ch;

		do {
			MobileService service = new MobileServiceImpl();
			PurchaseDetail pbean = new PurchaseDetail();
			System.out.println("1.Insert Mobile ID.\n");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Cutomer Name = ");
				String name = sc.next();
				System.out.println("Enter contact number = ");
				long phone = sc.nextLong();
				System.out.println("Enter Customer Email Id = ");
				String email = sc.next();
				System.out.println("Enter Mobile ID = ");
				int id = sc.nextInt();
				pbean.setMobileid(id);
				pbean.setCname(name);
				pbean.setPhoneno(phone);
				pbean.setMailid(email);

				try {
					int eid = service.addPurchaseDetails(pbean);
					System.out.println("Customer details Added Successfully\n" + eid);
				} catch (MobileException e) {
					e.printStackTrace();
					 
				}
				break;
			}
			System.out.println("Do you Want to continue?\n 1.Yes\n 2.No");
			ch = sc.nextInt();
		} while (ch > 0 && ch < 3);
		System.out.println("ThankYou! Welcome back Again.");

	}
}
