package com.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import com.mobile.bean.MobileBean;
import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;
import com.mobile.util.DBConnection;

public class MobileDaoImpl implements MobileDao {
	Connection con = null;
	Statement stmt = null;
	ResultSet rst = null;
	MobileBean mbean = new MobileBean();
	 

	public int getmobileId() {
		int id = 0;

		String myquery = "select purchaseid_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			rst = stmt.executeQuery(myquery);
			rst.next();
			id = rst.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addPurchaseDetails(PurchaseDetail bean) throws MobileException {
		Connection con = null;
		int id = 0;

		try {
			String cd = "select mobileid from mobiles";
			stmt = con.createStatement();
			rst = stmt.executeQuery(cd);
			while (rst.next()) {
				if (rst.getInt("mobileid") == bean.getMobileid()) {

					String cmd = "insert into purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) values (?,?,?,?,sysdate,?)";
					con = DBConnection.getConnection();
					id = getmobileId();
					PreparedStatement pstmt = con.prepareStatement(cmd);
					pstmt.setInt(1, id);
					pstmt.setString(2, bean.getCname());
					pstmt.setLong(3, bean.getPhoneno());
					pstmt.setString(4, bean.getMailid());
					pstmt.setLong(5, bean.getMobileid());
					int n = pstmt.executeUpdate();
					
					String sql = "update mobiles set quantity=quantity-1 where mobileid=?";
					PreparedStatement conn = con.prepareStatement(sql);
					rst = conn.executeQuery();
					if (rst != null) {
						System.out.println("Data Inserted Succesfully");
					}
				}
				else
				{
					System.out.println("Id does not exist!");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new MobileException("Unable to insert");
		}
		return id;

	}
}
