package com.mobile.dao;

import com.mobile.bean.PurchaseDetail;
import com.mobile.exception.MobileException;

public interface MobileDao {
	
	public int addPurchaseDetails(PurchaseDetail bean) throws MobileException;

}
