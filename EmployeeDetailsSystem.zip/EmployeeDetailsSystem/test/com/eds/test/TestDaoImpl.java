package com.eds.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.eds.bean.EmpDetailBean;
import com.eds.dao.EmpDetailDaoImpl;
import com.eds.exception.EmpDetailException;

public class TestDaoImpl {
	
	static EmpDetailDaoImpl employeeDao;
	static EmpDetailBean empBean;
	@BeforeClass
	public static void beforeClass()
	{
		employeeDao=new EmpDetailDaoImpl();
		empBean=new EmpDetailBean();
	}
	
	@Test
	public void testAddEmployee() throws EmpDetailException
	{
		empBean.setEmp_fname("Payal");
		empBean.setEmp_lname("Rathod");
		empBean.setEmp_contact(1234567890);
		empBean.setEmp_email("abcd@gmail.com");
		int id=employeeDao.addEmployee(empBean);
		 assertTrue(id>0);
	}
	
	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/

	@Test
	public void testViewEmployee()throws EmpDetailException
	{
		assertNotNull(employeeDao.viewEmployeeById(100));
	}
	
	@Test
	public void testById1() throws EmpDetailException {
		assertEquals("Jyoti", employeeDao.viewEmployeeById(100).getEmp_fname());
	}
	

}
