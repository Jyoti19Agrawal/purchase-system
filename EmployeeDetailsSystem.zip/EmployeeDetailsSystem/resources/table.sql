create table employee_tbl (empid number(6)primary key, emp_fname varchar2(1
0),emp_lname varchar2(15), emp_contact number(10),emp_doj date, emp_email varcha
r(15));

create sequence employeeid_sequence start with 100;

 

 