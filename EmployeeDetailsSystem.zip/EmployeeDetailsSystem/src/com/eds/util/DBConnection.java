package com.eds.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.eds.exception.EmpDetailException;

public class DBConnection {
	
	 
	public static Connection getConnection() throws EmpDetailException
	{
		Connection con=null;
		Properties prop =new Properties();
		try {
			FileReader fr=new FileReader("resources/jdbc.properties");
			prop.load(fr);
			String url=prop.getProperty("jdbcurl");
			String user=prop.getProperty("jdbcuser");
			String pass=prop.getProperty("jdbcpass");
			con= DriverManager.getConnection(url,user,pass);
		} catch (FileNotFoundException e) {
			 throw  new EmpDetailException("jdbc.properties file not found");
			 
		} catch (IOException e) {
			 throw new EmpDetailException("Unable to read properties file");
		} catch (SQLException e) {
			 throw new EmpDetailException("Unable to connect to database");
		}
		
		return(con);
		
		
	}
}
