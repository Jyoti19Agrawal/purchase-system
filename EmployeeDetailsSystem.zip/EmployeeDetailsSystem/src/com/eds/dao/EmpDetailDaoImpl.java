package com.eds.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.eds.bean.EmpDetailBean;
import com.eds.exception.EmpDetailException;
import com.eds.util.DBConnection;

public class EmpDetailDaoImpl implements EmpDetaildao {
	Logger logger=Logger.getLogger(EmpDetailDaoImpl.class);
	 public EmpDetailDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	Connection con = null;
	Statement stmt = null;
	ResultSet rst = null;
	PreparedStatement preparedStatement = null;

	public int generateEmployeeId() {
		int id = 0;
		Connection con = null;
		String myquery = "select employeeid_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			rst = stmt.executeQuery(myquery);
			rst.next();// to move cursor
			id = rst.getInt(1);// here 1 is the column 1 means id column
		} catch (Exception e) {
			e.printStackTrace();
		}
		return id;

	}

	@Override
	public int addEmployee(EmpDetailBean bean) throws EmpDetailException {
		logger.debug("Add employee method called from dao layer.");
		logger.info("Add Employee method called.");
		int id = 0;
		String cmd = "insert into employee_tbl(empid,emp_fname,emp_lname,emp_contact,emp_doj,emp_email) values (?,?,?,?,sysdate,?)";
		try {
			logger.warn("Database connected in dao layer");
			con = DBConnection.getConnection();
			id = generateEmployeeId();
			PreparedStatement pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmp_fname());
			pstmt.setString(3, bean.getEmp_lname());
			pstmt.setLong(4, bean.getEmp_contact());
			pstmt.setString(5, bean.getEmp_email());
			int n = pstmt.executeUpdate();
			logger.debug("Inserted Successfully");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			throw new EmpDetailException("Unable to insert");
		}
		return id;
	}

	@Override
	public EmpDetailBean viewEmployeeById(int id) throws EmpDetailException {
		logger.debug("View Employee ID called from dao layer");
		logger.info("View employee Id called.");
		EmpDetailBean bean = new EmpDetailBean();
		try {
			logger.warn("Database Connected in dao layer for view ID");
			con = DBConnection.getConnection();
			String cmd = "select empid,emp_fname,emp_lname,emp_contact,emp_doj,emp_email from employee_tbl where empid="
					+ id;
			preparedStatement = con.prepareStatement(cmd);
			rst = preparedStatement.executeQuery();

			if (rst.next()) {
				bean.setEmp_id(rst.getInt(1));
				bean.setEmp_fname(rst.getString(2));
				bean.setEmp_lname(rst.getString(3));
				bean.setEmp_contact(rst.getLong(4));
				bean.setEmp_doj(rst.getDate(5));
				bean.setEmp_email(rst.getString(6));
				logger.debug("viewed successful");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new EmpDetailException("Technical problem occured.");
		}
		return bean;

	}

}
