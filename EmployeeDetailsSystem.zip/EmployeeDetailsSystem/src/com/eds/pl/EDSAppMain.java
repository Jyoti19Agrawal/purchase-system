package com.eds.pl;

import java.util.List;
import java.util.Scanner;

import com.eds.bean.EmpDetailBean;
import com.eds.exception.EmpDetailException;
import com.eds.service.EmpDetailService;
import com.eds.service.EmpDetailServiceImpl;

public class EDSAppMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int ch;

		do {
			EmpDetailBean bean = new EmpDetailBean();
			EmpDetailService service = new EmpDetailServiceImpl();

			System.out
					.println("1.Insert Employee Details.\n2.View Employee Detail By Id.\n"
							+ "3.Exit");
			System.out.println("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Your First Name = ");
				String fname = sc.next();
				System.out.println("Enter Your Last Name = ");
				String lname = sc.next();
				System.out.println("Enter Your Contact Number = ");
				long cont = sc.nextLong();
				System.out.println("Enter Your Email = ");
				String email = sc.next();

				bean.setEmp_fname(fname);
				bean.setEmp_lname(lname);
				bean.setEmp_contact(cont);
				bean.setEmp_email(email);
				try {

					if (service.validateEmployee(bean)) {
						int id = service.addEmployee(bean);
						System.out.println("Employee ID added Successfully\n"
								+ id);
					}
				} catch (EmpDetailException e) {
					e.printStackTrace();
					System.out.println("Please enter valid details.");
				}
				break;

			case 2:
				System.out.println("Enter Employee ID: ");
				int empid = sc.nextInt();
				try {

					EmpDetailBean id = service.viewEmployeeById(empid);
					 {
						System.out
								.println("Employee Details : \n-----------------\n"
										+ id);

					}
				}

				catch (EmpDetailException e) {
					System.out.println("No Record found");
				}

				break;
			default:
				System.out.println("Please! choose valid Number");
			}
			System.out.println("Do you Want to continue?\n 1.Yes\n 2.No");
			ch = sc.nextInt();
		} while (ch > 0 && ch < 2);
		System.out.println("ThankYou! Welcome back Again.");

	}
}
