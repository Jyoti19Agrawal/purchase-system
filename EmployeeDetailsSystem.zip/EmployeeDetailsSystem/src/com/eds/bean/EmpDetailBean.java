package com.eds.bean;

import java.util.Date;

public class EmpDetailBean {
	private int emp_id;
	private String emp_fname;
	private String emp_lname;
	private long emp_contact;
	private Date emp_doj;
	private String emp_email;
	public EmpDetailBean() {
		super();
		 
	}
	public EmpDetailBean(int emp_id, String emp_fname, String emp_lname,
			long emp_contact, Date emp_doj, String emp_email) {
		super();
		this.emp_id = emp_id;
		this.emp_fname = emp_fname;
		this.emp_lname = emp_lname;
		this.emp_contact = emp_contact;
		this.emp_doj = emp_doj;
		this.emp_email = emp_email;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_fname() {
		return emp_fname;
	}
	public void setEmp_fname(String emp_fname) {
		this.emp_fname = emp_fname;
	}
	public String getEmp_lname() {
		return emp_lname;
	}
	public void setEmp_lname(String emp_lname) {
		this.emp_lname = emp_lname;
	}
	public long getEmp_contact() {
		return emp_contact;
	}
	public void setEmp_contact(long emp_contact) {
		this.emp_contact = emp_contact;
	}
	public Date getEmp_doj() {
		return emp_doj;
	}
	public void setEmp_doj(Date emp_doj) {
		this.emp_doj = emp_doj;
	}
	public String getEmp_email() {
		return emp_email;
	}
	public void setEmp_email(String emp_email) {
		this.emp_email = emp_email;
	}
	@Override
	public String toString() {
		return  "Employee Id         = " + emp_id + 
				"\nEmployee First Name= " + emp_fname+
				"\nEmployee Last Name = " + emp_lname + 
				"\nContact number     = " + emp_contact+
				"\nDate Of Joining    = " + emp_doj + 
				"\nEmployee Email     = " + emp_email;
	}
	
	
	
	
	

}
