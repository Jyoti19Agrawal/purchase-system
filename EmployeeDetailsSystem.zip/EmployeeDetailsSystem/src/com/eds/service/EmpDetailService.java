package com.eds.service;

import java.util.List;

import com.eds.bean.EmpDetailBean;
import com.eds.exception.EmpDetailException;

public interface EmpDetailService {
	
	public int addEmployee(EmpDetailBean bean) throws EmpDetailException;
	public EmpDetailBean viewEmployeeById(int empid) throws EmpDetailException;
	public boolean validateEmployee(EmpDetailBean bean) throws EmpDetailException;
}
